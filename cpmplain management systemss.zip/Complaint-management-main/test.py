import pyodbc; print(pyodbc.drivers())
# ['SQL Server', ... , 'ODBC Driver 17 for SQL Server']
